export default function Navbar() {
  return (
    <nav className="p-6 bg-slate-800 text-xl font-bold">
      Sezan Enterprise
    </nav>
  );
}