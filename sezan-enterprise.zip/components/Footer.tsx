export default function Footer() {
  return (
    <footer className="p-6 bg-slate-800 text-center">
      © Sezan Enterprise
    </footer>
  );
}