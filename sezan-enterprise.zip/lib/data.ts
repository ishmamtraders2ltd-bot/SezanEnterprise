export const products = [
  { slug: 'r134a', name: 'R134a Refrigerant', category: 'Refrigerant' },
  { slug: 'compressor-oil', name: 'Compressor Oil', category: 'AC Parts' }
];