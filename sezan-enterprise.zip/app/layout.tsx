import './globals.css';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export const metadata = {
  title: 'Sezan Enterprise | HVAC Refrigerant & AC Parts',
  description: 'HVAC refrigerant and AC fridge parts wholesaler at Joy Kali Mandir'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-900 text-white">
        <Navbar />
        {children}
        <Footer />
      </body>
    </html>
  );
}