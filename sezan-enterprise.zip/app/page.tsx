export default function Home() {
  return (
    <main className="p-12 text-center">
      <h1 className="text-5xl font-bold text-orange-500">Sezan Enterprise</h1>
      <p className="mt-4 text-xl">HVAC Refrigerant, AC & Fridge Parts Wholesaler</p>
      <p className="text-gray-400">Joy Kali Mandir</p>
    </main>
  );
}